import{J as s,U as u}from"./index-Dqv9RNTW.js";function m(e){return s(`query ($kg: bigint!) {
      class(where: { kindergarten_id: { _eq: $kg } }, order_by: { sort_order: asc }) {
        id class_name sort_order status
        children_aggregate { aggregate { count } }
      }
    }`,{kg:e}).then(t=>t.class)}function p(e,t){return t?s("mutation ($id: bigint!, $set: class_set_input!) { update_class_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: class_insert_input!) { insert_class_one(object: $object) { id } }",{object:e})}function h(e){return s("mutation ($id: bigint!) { delete_class_by_pk(id: $id) { id } }",{id:e})}function $(e,t=""){const i={kindergarten_id:{_eq:e}};return t&&(i.name={_ilike:`%${t}%`}),s(`query ($where: child_bool_exp) {
      child(where: $where, order_by: { created_at: desc }) {
        id name gender birth_date parent_name parent_phone remark status
        class_id class { class_name }
      }
    }`,{where:i}).then(n=>n.child)}function g(e,t){return t?s("mutation ($id: bigint!, $set: child_set_input!) { update_child_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: child_insert_input!) { insert_child_one(object: $object) { id } }",{object:e})}function b(e){return s(`query ($kg: bigint!) {
      study_group(where: { kindergarten_id: { _eq: $kg } }, order_by: { id: asc }) {
        id group_name course_type remark status
        members { id child_id child { name } }
      }
    }`,{kg:e}).then(t=>t.study_group)}function f(e,t){return t?s("mutation ($id: bigint!, $set: study_group_set_input!) { update_study_group_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: study_group_insert_input!) { insert_study_group_one(object: $object) { id } }",{object:e})}function k(e){return s("mutation ($id: bigint!) { delete_study_group_by_pk(id: $id) { id } }",{id:e})}function y(e,t){const i=t.map(n=>({study_group_id:e,child_id:n}));return s(`mutation SetMembers($groupId: bigint!, $students: [group_member_insert_input!]!) {
      delete_group_member(where: { study_group_id: { _eq: $groupId } }) { affected_rows }
      insert_group_member(objects: $students) { affected_rows }
    }`,{groupId:e,students:i})}function w(){return s(`query {
      course(where: { status: { _eq: "启用" } }, order_by: { sort_order: asc }) {
        id course_type course_name description
        lessons(where: { status: { _eq: "启用" } }, order_by: { sort_order: asc }) {
          id lesson_name topic outline sort_order
        }
      }
    }`).then(e=>e.course)}function j(){return s(`query {
      course(order_by: { sort_order: asc }) {
        id course_type course_name description status
        lessons(order_by: { sort_order: asc }) {
          id lesson_name topic outline sort_order status
          items(order_by: { sort_order: asc }) {
            id sort_order teaching_note
            item { id content pinyin meaning item_type level }
          }
        }
      }
    }`).then(e=>e.course)}function q(e,t){return t?s("mutation ($id: bigint!, $set: lesson_set_input!) { update_lesson_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: lesson_insert_input!) { insert_lesson_one(object: $object) { id } }",{object:e})}function v(e,t,i,n){return s(`mutation Swap($idA: bigint!, $sortA: bigint!, $idB: bigint!, $sortB: bigint!) {
      update_lesson_by_pk(pk_columns: {id: $idA}, _set: { sort_order: $sortB }) { id }
      update_lesson_by_pk(pk_columns: {id: $idB}, _set: { sort_order: $sortA }) { id }
    }`,{idA:e,sortA:t,idB:i,sortB:n})}function I(e){return s(`mutation DeleteLesson($id: bigint!) {
      delete_lesson_item(where: { lesson_id: { _eq: $id } }) { affected_rows }
      delete_lesson_by_pk(id: $id) { id }
    }`,{id:e})}function S(e,t){const i=t.map((n,c)=>({lesson_id:e,item_id:n.item_id,sort_order:c+1,teaching_note:n.teaching_note||null}));return s(`mutation SaveLessonItems($lid: bigint!, $rows: [lesson_item_insert_input!]!) {
      delete_lesson_item(where: { lesson_id: { _eq: $lid } }) { affected_rows }
      insert_lesson_item(objects: $rows) { affected_rows }
    }`,{lid:e,rows:i})}function C(e,t={}){const i={kindergarten_id:{_eq:e}};return t.teacherId&&(i.teacher_id={_eq:t.teacherId}),t.status&&(i.status={_eq:t.status}),s(`query ($where: schedule_bool_exp) {
      schedule(where: $where, order_by: { lesson_date: desc, start_time: asc }) {
        id lesson_date start_time duration_minutes note status
        lesson { id lesson_name topic outline sort_order course { id course_type course_name } }
        study_group { id group_name course_type }
        teacher { id name }
        students { id child_id child { name } attendance performance }
        lesson_record { overall_summary }
      }
    }`,{where:i}).then(n=>n.schedule)}function A(e,t){const i={...e,students:{data:t.map(n=>({child_id:n}))}};return s(`mutation CreateSchedule($object: schedule_insert_input!) {
      insert_schedule_one(object: $object) { id }
    }`,{object:i})}function L(e,t){return s("mutation ($id: bigint!, $set: schedule_set_input!) { update_schedule_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:e,set:t})}function x(e){return s(`mutation DeleteSchedule($id: bigint!) {
      delete_schedule_student(where: { schedule_id: { _eq: $id } }) { affected_rows }
      delete_lesson_record(where: { schedule_id: { _eq: $id } }) { affected_rows }
      delete_schedule_by_pk(id: $id) { id }
    }`,{id:e})}function P(e,t,i,n){const c={overall_summary:t,teacher_id:n,schedule_id:e},o=i.map((d,r)=>`$sid${r}: bigint!, $set${r}: schedule_student_set_input!`).join(", "),a=i.map((d,r)=>`u${r}: update_schedule_student_by_pk(pk_columns: {id: $sid${r}}, _set: $set${r}) { id }`).join(`
      `),_={sid:e,rec:c};return i.forEach((d,r)=>{_[`sid${r}`]=d.where.id._eq,_[`set${r}`]=d._set}),s(`mutation SaveRecord($sid: bigint!, $rec: lesson_record_insert_input!${o?", "+o:""}) {
      delete_lesson_record(where: { schedule_id: { _eq: $sid } }) { affected_rows }
      insert_lesson_record_one(object: $rec) { id }
      update_schedule_by_pk(pk_columns: {id: $sid}, _set: { status: "已完成" }) { id }
      ${a}
    }`,_)}function B(e,t){const i={kindergarten_id:{_eq:e}};return t&&(i.assess_month={_eq:t}),s(`query ($where: assessment_bool_exp) {
      assessment(where: $where, order_by: { child_id: asc }) {
        id assess_month score comment
        child { id name }
        course { id course_type }
        teacher { name }
      }
    }`,{where:i}).then(n=>n.assessment)}function G(e){return s(`mutation SaveAssessment($object: assessment_insert_input!, $childId: bigint!, $courseId: bigint!, $month: String!) {
      delete_assessment(where: { child_id: { _eq: $childId }, course_id: { _eq: $courseId }, assess_month: { _eq: $month } }) { affected_rows }
      insert_assessment_one(object: $object) { id }
    }`,{object:e,childId:e.child_id,courseId:e.course_id,month:e.assess_month})}function D(e){return s(`query ($kg: bigint!) {
      user(where: { kindergarten_id: { _eq: $kg } }, order_by: { id: asc }) {
        id name phone role status account_id
      }
    }`,{kg:e}).then(t=>t.user)}function E(e,t){return t?s("mutation ($id: bigint!, $set: user_set_input!) { update_user_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: user_insert_input!) { insert_user_one(object: $object) { id } }",{object:e})}async function F({name:e,phone:t,role:i,kindergarten_id:n,password:c}){var d;const o=await s("query ($phone: String!) { user(where: { phone: { _eq: $phone } }) { id account_id kindergarten_id } }",{phone:t}).then(r=>r.user[0]);if(o!=null&&o.account_id){const r=new Error("该手机号已开通过账号，可直接登录");throw r.code="ACCOUNT_EXISTS",r}const a=await u(t,c);if(o)return await s("mutation ($id: bigint!, $accountId: bigint!) { update_user_by_pk(pk_columns: {id: $id}, _set: { account_id: $accountId }) { id } }",{id:o.id,accountId:a.id}),{userId:o.id,accountId:a.id,rebound:!0};const _=await s("mutation ($object: user_insert_input!) { insert_user_one(object: $object) { id } }",{object:{name:e,phone:t,role:i,status:"在职",kindergarten_id:n,account_id:a.id}});return{userId:(d=_==null?void 0:_.insert_user_one)==null?void 0:d.id,accountId:a.id,rebound:!1}}function J(){return s(`query {
      course_package(order_by: { sort_order: asc, id: asc }) {
        id package_name description status sort_order
        items(order_by: { day_of_week: asc, start_time: asc }) {
          id day_of_week start_time duration_minutes
          lesson { id lesson_name topic course { id course_type course_name } }
        }
      }
    }`).then(e=>e.course_package)}function K(e,t){return t?s("mutation ($id: bigint!, $set: course_package_set_input!) { update_course_package_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: course_package_insert_input!) { insert_course_package_one(object: $object) { id } }",{object:e})}function M(e,t){const i=t.map(n=>({package_id:e,lesson_id:n.lesson_id,day_of_week:n.day_of_week,start_time:n.start_time,duration_minutes:n.duration_minutes||30}));return s(`mutation SavePackageItems($pid: bigint!, $items: [course_package_item_insert_input!]!) {
      delete_course_package_item(where: { package_id: { _eq: $pid } }) { affected_rows }
      insert_course_package_item(objects: $items) { affected_rows }
    }`,{pid:e,items:i})}function O(e){return s(`mutation DeletePackage($id: bigint!) {
      delete_course_package_item(where: { package_id: { _eq: $id } }) { affected_rows }
      delete_course_package_by_pk(id: $id) { id }
    }`,{id:e})}function R(e){return s(`mutation BatchCreateSchedules($objects: [schedule_insert_input!]!) {
      insert_schedule(objects: $objects) { affected_rows returning { id } }
    }`,{objects:e})}function T(e=[0,1]){return s(`query ($levels: [bigint!]!) {
      literacy_item(where: { level: { _in: $levels }, status: { _eq: "启用" } }, order_by: { level: asc, sort_order: asc }) {
        id item_type level content pinyin meaning components_note teaching_tip sort_order
        courseware { id explanation stroke_groups status }
      }
    }`,{levels:e}).then(t=>t.literacy_item)}async function W(e,t){const i=await s("query ($itemId: bigint!) { char_courseware(where: { item_id: { _eq: $itemId } }) { id } }",{itemId:e}).then(n=>n.char_courseware[0]);return i?s("mutation ($id: bigint!, $set: char_courseware_set_input!) { update_char_courseware_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:i.id,set:t}):s("mutation ($object: char_courseware_insert_input!) { insert_char_courseware_one(object: $object) { id } }",{object:{...t,item_id:e}})}function z(e){return s(`query ($kg: bigint!) {
      schedule(where: { kindergarten_id: { _eq: $kg }, status: { _eq: "已完成" } }) {
        study_group_id lesson_id
      }
    }`,{kg:e}).then(t=>t.schedule)}function H(e){return s(`query ($lid: bigint!) {
      lesson_item(where: { lesson_id: { _eq: $lid } }, order_by: { sort_order: asc }) {
        id sort_order teaching_note
        item { id content pinyin meaning item_type level teaching_tip
          courseware { id explanation stroke_groups status }
        }
      }
    }`,{lid:e}).then(t=>t.lesson_item)}function N(){return s(`query {
      kindergarten(order_by: { id: asc }) {
        id name contact_name contact_phone status remark
        staff_users_aggregate { aggregate { count } }
        children_aggregate { aggregate { count } }
        schedules_aggregate { aggregate { count } }
      }
    }`).then(e=>e.kindergarten)}function X(e,t){return t?s("mutation ($id: bigint!, $set: kindergarten_set_input!) { update_kindergarten_by_pk(pk_columns: {id: $id}, _set: $set) { id } }",{id:t,set:e}):s("mutation ($object: kindergarten_insert_input!) { insert_kindergarten_one(object: $object) { id } }",{object:e})}export{y as A,z as B,L as C,x as D,A as E,R as F,H as G,P as H,B as I,G as J,w as a,J as b,F as c,K as d,O as e,N as f,M as g,T as h,W as i,j,v as k,I as l,q as m,S as n,$ as o,C as p,D as q,E as r,X as s,m as t,g as u,h as v,p as w,b as x,k as y,f as z};
